package Pages;

import org.openqa.selenium.chrome.ChromeDriver;

import Base.ProjectSpecificMthods;

public class LoginPage extends ProjectSpecificMthods  {
	
	
	 public LoginPage(ChromeDriver driver) {
			
			this.driver=driver;
	    }
	
	public LoginPage enterUsername(String user) {
		driver.findElementById(prop.getProperty("LoginPage.UserName.id")).sendKeys(user);
		
		return this;
	}
	
	
	public LoginPage enterPassword(String Pass) {
		driver.findElementById(prop.getProperty("LoginPage.Password.id")).sendKeys(Pass);
		return this;
	}
	
	
	public HomePage clickLoginButton() {
		driver.findElementByClassName(prop.getProperty("LoginPage.Login.classname")).click();
		return new HomePage(driver);
	}

}
