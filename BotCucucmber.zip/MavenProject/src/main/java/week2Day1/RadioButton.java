package week2Day1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButton {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./ChromeDriver/chromedriver.exe");
		
		String property = System.getProperty("webdriver.chrome.driver");
		
		System.out.println(property);
					
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
						

		//to maximize the browser 
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  
		//to load application url
		driver.get("http://leafground.com/");
		
		driver.findElementByXPath("//h5[contains(text(),'Radio Button')]").click();
		
		driver.findElementByXPath("//label[@for='yes']/input").click();
		
		WebElement checkboxEnabled = driver.findElementByXPath("//label[@for='Checked']/input");
		WebElement unchecked = driver.findElementByXPath("//label[@for='Unchecked']/input");
		unchecked.click();
		
		if(checkboxEnabled.isSelected()) {
			System.out.println("Default Selected Radio button is TRUE" );
		}
		else if(unchecked.isSelected()) {
			System.out.println(" Unchecked Radio button is TRUE");
		}
		else {
			System.out.println("NO checkbox is checked");
		}

		WebElement ageGroup = driver.findElementByXPath("//input[@name='age' and @value='1']");
		System.out.println("Seleted age group is 21 to 40 years "+ageGroup.isSelected());
		
		Thread.sleep(3000);
		driver.quit();
		
	}

}
