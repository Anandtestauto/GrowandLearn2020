package week2Day1;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Button {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		
		String property = System.getProperty("webdriver.chrome.driver");
		
		System.out.println(property);
					
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
						

		//to maximize the browser 
		driver.manage().window().maximize();
  
		//to load application url
		/*
		 * driver.get("http://leafground.com/");
		 * 
		 * driver.findElementByXPath("(//h5[contains(text(),'Button')])[1]").click();
		 * Thread.sleep(3000);
		 * driver.findElementByXPath("//button[text()='Go to Home Page']").click();
		 * Thread.sleep(3000);
		 * driver.findElementByXPath("(//h5[contains(text(),'Button')])[1]").click();
		 * WebElement getPos =
		 * driver.findElementByXPath("//button[text()='Get Position']");
		 * System.out.println(getPos.getLocation().getX());
		 * System.out.println(getPos.getLocation().getY());
		 * 
		 * String cssValue =
		 * driver.findElementByXPath("//button[text()='What color am I?']").getCssValue(
		 * "background-color"); System.out.println(cssValue);
		 * 
		 * WebElement size =
		 * driver.findElementByXPath("//button[contains(text(),'What is my size?')]");
		 * System.out.println(size.getSize());
		 * 
		 * Thread.sleep(3000);
		 * 
		 * driver.get("http://leafground.com/");
		 * driver.findElementByXPath("//h5[text()='Image']").click();
		 */
		
		driver.get("https://www.makemytrip.com/");
		
		  WebElement loginOrCreateAcc = driver.findElementByCssSelector(".makeFlex.hrtlCenter.font10.makeRelative.lhUser");
		  
		  
		  WebDriverWait expWait=new WebDriverWait(driver,Duration.ofSeconds(10));
		  expWait.until(ExpectedConditions.elementToBeClickable(loginOrCreateAcc));
		  loginOrCreateAcc.click();
		 
		
		/*
		 * Alert loginAlert = driver.switchTo().alert();
		 * 
		 * loginAlert.sendKeys("8939111917");
		 */
		
		
		  WebElement flights = driver.findElement(By.cssSelector("li.menu_Flights>a"));
		  WebDriverWait expWait1=new WebDriverWait(driver,Duration.ofSeconds(10));
		  expWait1.until(ExpectedConditions.elementToBeClickable(flights));
		  flights.click();
		  driver.findElementByCssSelector("input#fromCity[type='text']").click();
		 
	}

}
