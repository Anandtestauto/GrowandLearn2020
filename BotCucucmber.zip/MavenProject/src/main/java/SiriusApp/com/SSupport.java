package SiriusApp.com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class SSupport {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		String property = System.getProperty("webdriver.chrome.driver");	
		System.out.println(property);
		//To disable notifications of the browser
		ChromeOptions options=new ChromeOptions();
		options.setHeadless(false);
		//To open Chrome Browser
		WebDriver driver = new ChromeDriver(options);
		//to maximize the browser 
		driver.manage().window().maximize();
		driver.get("https://siriusukfta1.uk1test.group.internal/fta1/RRP.UI.Web/Default.aspx?_height=816&_width=1536");
		WebElement maintenance = driver.findElement(By.xpath("//a[@href='/FTA1/Rrp.UI.Web/Maintenance.aspx']"));
		maintenance.click();
		WebElement operations = driver.findElement(By.partialLinkText("Operations"));
		Actions builder=new Actions(driver);
		builder.moveToElement(operations).perform();
		driver.findElement(By.xpath("//span[contains(text(),'Reporting Stored Pr...')]/..")).click();
		WebElement category = driver.findElement(By.id("sfrmSelectStoredProcedure_ctl00_ddlstStoredProcedureCategory__rrp_list_ddlstStoredProcedureCategory"));	
		Select select=new Select(category);
		select.selectByVisibleText("DividendReports");
		
	}

}
