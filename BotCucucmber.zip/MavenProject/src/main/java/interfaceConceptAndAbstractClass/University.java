package interfaceConceptAndAbstractClass;

public abstract class University {
	
	int dept=10;

	abstract void ug(int a, int b);
	
	void pg() {
		System.out.println("Implemented Method");
	}
	
}
