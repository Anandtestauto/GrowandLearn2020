package collections.week3.Day2;

import java.io.IOException;

public class ExceptionHandling {

	public static void main(String[] args) throws IOException {

		int x = 10;
		int y = 0;

		String[] testString = { "Test1", "Test2" };
		
		
		try{
			System.out.println(testString[2]);
			int z=x/y;
			System.out.println(z);
			
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println(e);
			//e.printStackTrace();
		}
	
		catch(ArithmeticException e){
			System.out.println(e);
				//e.printStackTrace();
		}	
			
		
		catch(Exception e)
		{
			System.out.println(e);
			//e.printStackTrace();
		}
		/*
		 * In finally block we can include which needs to be executed at the end of the program
		 * For ex; Termination database connection, server connerction
		 * 
		 */
		  finally { 
			  Runtime.getRuntime().exec("taskkill /f /im chrome.exe");
			  System.out.println("Finally block will also be exeuted when the catch block is not included"); 
		  }
		 
		
		
		System.out.println("This line will not be excuted if the exception is not handled");


		
		
		
		// Nester Try Catch

		/*
		 * try{ System.out.println(testString[1]);
		 * 
		 * try { int z=x/y; System.out.println(z); } catch(ArithmeticException e) {
		 * System.out.println(e); //e.printStackTrace(); }
		 * 
		 * }catch(ArrayIndexOutOfBoundsException e) { System.out.println(e);
		 * //e.printStackTrace(); }
		 * 
		 * 
		 * catch(Exception e) { System.out.println(e); //e.printStackTrace(); }
		 * 
		 * finally { System.out.
		 * println("Finally block will also be exeuted when the catch block is not included"
		 * ); }
		 * 
		 * 
		 * 
		 * System.out.
		 * println("This line will not be excuted if the exception is not handled");
		 * 
		 */ }

}
