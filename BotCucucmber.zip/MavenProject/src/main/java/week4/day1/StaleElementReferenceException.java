package week4.day1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class StaleElementReferenceException {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");	
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");	
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement userName = driver.findElement(By.id("username"));
		userName.sendKeys("demsalesmanager");
		
		WebElement pwd = driver.findElement(By.id("password"));
		pwd.sendKeys("crmsfa");
		/*
		 * driver.navigate().refresh(); try { userName.sendKeys("demsalesmanager");
		 * pwd.sendKeys("crmsfa"); }
		 * catch(org.openqa.selenium.StaleElementReferenceException e) { userName =
		 * driver.findElement(By.id("username")); userName.sendKeys("demsalesmanager");
		 * }
		 */
		WebElement login = driver.findElement(By.className("decorativeSubmit"));
		login.click();
		login.click();
	}

}
