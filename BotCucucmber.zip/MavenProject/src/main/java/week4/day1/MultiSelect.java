package week4.day1;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MultiSelect {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./ChromeDriver/chromedriver.exe");
		
		String property = System.getProperty("webdriver.chrome.driver");
		
		System.out.println(property);
					
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
		//to maximize the browser 
		driver.manage().window().maximize();
		driver.get("https://jqueryui.com/selectable/");
		//to get inside frame
		driver.switchTo().frame(0);
		
		Actions builder=new Actions(driver);
		//WebElement item1 = driver.findElementByXPath("//ol[@id='selectable']/li[1]");
		
		//WebElement item3 = driver.findElementByXPath("//ol[@id='selectable']/li[2]");
		
		WebElement item5 = driver.findElementByXPath("//ol[@id='selectable']/li[3]");
		//Select 1,3,5
		Thread.sleep(2000);
		builder.keyDown(Keys.CONTROL).click(item5).keyUp(Keys.CONTROL).perform();
		
		Thread.sleep(2000);
		
	
		

	}

}
