package week4.day1;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EQIPortal {
	
	public static void main(String[] args) throws InterruptedException {
	
	System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
	RemoteWebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
		/*
		 * driver.get("http://grclopsnlbm910/OPSPortal/Default.aspx");
		 * Thread.sleep(5000);
		 * driver.findElementByLinkText("Sign in as a different user").click();
		 * 
		 * //driver.get("http://username:password@www.example.com");
		 */
		 
		 driver.get("http://thiyagk:Jan@2021@grclopsnlbm910/OPSPortal/AccessDenied.aspx?Redirect=~/Default.aspx");
		 Thread.sleep(10000);
		 WebElement FTA2 = driver.findElementByLinkText("FTA2");
		/*
		 * WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(10));
		 * wait.until(ExpectedConditions.elementToBeClickable(FTA2));
		 */
		 FTA2.click();
}
}