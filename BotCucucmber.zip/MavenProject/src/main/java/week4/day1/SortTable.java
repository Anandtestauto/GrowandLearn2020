package week4.day1;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SortTable {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		String property = System.getProperty("webdriver.chrome.driver");
		System.out.println(property);
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
		//to maximize the browser 
		driver.manage().window().maximize();
		//to load application url
		driver.get("http://leafground.com/");
		driver.findElementByCssSelector("a[class='wp-categories-link maxheight'][href='pages/sorttable.html']").click();
		int rowcount = driver.findElementsByXPath("//table/thead/following-sibling::tbody/tr").size();
		
		for (int i=1;i<=rowcount;i++) {
			List<WebElement> name = driver.findElementsByXPath("//table/thead/following-sibling::tbody/tr["+i+"]/td[2]");
			
			List<String> nameList=new ArrayList<String>();
			nameList.addAll(nameList);
			
			
			/*
			 * if(text.contains("QA Software Engineer")) { System.out.println(text); }
			 */
		}
	}

}
