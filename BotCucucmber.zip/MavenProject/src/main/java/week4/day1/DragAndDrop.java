package week4.day1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class DragAndDrop {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		
		String property = System.getProperty("webdriver.chrome.driver");
		
		System.out.println(property);
					
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
		//to maximize the browser 
		driver.manage().window().maximize();
		driver.get("https://jqueryui.com");
		//to get inside frame
		
		driver.findElementByLinkText("Droppable").click();
		driver.switchTo().frame(0);
		Actions builder=new Actions(driver);
		Thread.sleep(3000);
		WebElement source = driver.findElementById("draggable");
		WebElement target = driver.findElementById("droppable");
		Thread.sleep(3000);
	
		builder.dragAndDrop(source, target).perform();
		
	
	
		
		

	}

}
