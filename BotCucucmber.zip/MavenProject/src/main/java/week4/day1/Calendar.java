package week4.day1;

import org.openqa.selenium.chrome.ChromeDriver;

public class Calendar {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		String property = System.getProperty("webdriver.chrome.driver");
		System.out.println(property);
		//To open Chrome Browser
		ChromeDriver driver = new ChromeDriver();
		//to maximize the browser 
		driver.manage().window().maximize();
		//to load application url
		driver.get("http://leafground.com/");
		driver.findElementByCssSelector(".col-lg-3.col-md-3.col-sm-3:nth-of-type(12)").click();
		driver.findElementByCssSelector("input#datepicker").click();
		driver.findElementByXPath("//table/thead/following-sibling::tbody/tr[2]/td[5]").click();
		
		

	}

}
