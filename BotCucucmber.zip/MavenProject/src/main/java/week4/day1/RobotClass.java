package week4.day1;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RobotClass {

	public static void main(String[] args) throws AWTException, InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		
		String property = System.getProperty("webdriver.chrome.driver");
		
		System.out.println(property);
		
		WebDriver driver = new ChromeDriver();

		//to maximize the browser 
		driver.manage().window().maximize();
		/*
		 * driver.get("http://leafground.com/"); Thread.sleep(3000); driver.
		 * findElementByCssSelector("a[class='wp-categories-link maxheight'][href='pages/upload.html']"
		 * ).click(); Thread.sleep(3000);
		 * driver.findElementByXPath("//input[@name='filename'][@type='file']").
		 * sendKeys("D:\\Selenium Docs\\CreateLeadTD.xlsx");
		 */
		/*
		 * ClipboardOwner owner=null; String
		 * path="D:\\Selenium Docs\\CreateLeadTD.xlsx";
		 * 
		 * Robot robot=new Robot(); StringSelection attachmentPath=new
		 * StringSelection(path);
		 * Toolkit.getDefaultToolkit().getSystemClipboard().setContents(attachmentPath,
		 * owner);
		 * 
		 * robot.setAutoDelay(5000); robot.keyPress(KeyEvent.VK_CONTROL);
		 * robot.keyPress(KeyEvent.VK_V); robot.keyRelease(KeyEvent.VK_CONTROL);
		 * robot.keyRelease(KeyEvent.VK_V);
		 * 
		 * robot.setAutoDelay(5000); robot.keyPress(KeyEvent.VK_ENTER);
		 * 
		 * 
		 */
		/*
		 * String URL = "https://demoqa.com/upload-download";
		 * 
		 * //Start Browser driver.get(URL);
		 * 
		 * //maximize browser driver.manage().window().maximize();
		 * 
		 * 
		 * // This will click on Browse button WebElement selectFile =
		 * driver.findElement(By.id("uploadFile")); Thread.sleep(2000); //click Browse
		 * button selectFile.click();
		 * 
		 * //Create object of Robot class Robot robot = new Robot(); //Code to Enter
		 * D1.txt //Press Shify key
		 * 
		 * robot.keyPress(KeyEvent.VK_SHIFT); //Press d , it gets typed as upper case D
		 * as Shift key is pressed robot.keyPress(KeyEvent.VK_D); //Release SHIFT key to
		 * release upper case effect robot.keyRelease(KeyEvent.VK_SHIFT);
		 * robot.keyPress(KeyEvent.VK_1); robot.keyPress(KeyEvent.VK_PERIOD);
		 * robot.keyPress(KeyEvent.VK_T); robot.keyPress(KeyEvent.VK_X);
		 * robot.keyPress(KeyEvent.VK_T);
		 * 
		 * //Press ENTER to close the popup robot.keyPress(KeyEvent.VK_ENTER);
		 * 
		 * //Wait for 1 sec Thread.sleep(1000);
		 * 
		 * //This is just a verification part, accept alert selectFile =
		 * driver.findElement(By.id("uploadButton"));
		 * 
		 * selectFile.click(); WebDriverWait wait = new WebDriverWait(driver, 10); Alert
		 * myAlert = wait.until(ExpectedConditions.alertIsPresent()); //Accept the Alert
		 * myAlert.accept();
		 */
		
		//System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	
		driver.manage().window().maximize();
		driver.get("https://www.naukri.com/");	
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);		

		WebElement uploadButton = driver.findElement(By.xpath("//label[contains(text(),'Upload CV')]"));
		Actions builder = new Actions(driver);
		builder.moveToElement(uploadButton).click().perform();
		
		Thread.sleep(5000);
		
		// Store the copied text in the clipboard
		StringSelection stringSelection = new StringSelection("D:\\Selenium Docs\\cuccumberPOMXML.txt");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
			
		// Paste it using Robot class
		Robot robot = new Robot();

		// Enter to confirm it is uploaded
		robot.keyPress(KeyEvent.VK_CONTROL);			
		robot.keyPress(KeyEvent.VK_V);

		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);	

		Thread.sleep(5000);

		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
			
		//Thread.sleep(3000);
		//driver.findElementById("file_upload").sendKeys("C:\\Users\\hp\\Desktop\\Resume.docx");
		
	}
	}
