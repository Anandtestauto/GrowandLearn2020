package week3.Day2;

import week3.Day1.BMW;
import week3.Day1.Car;

public class Test extends BMW {
	
	public static void main(String[] args) {
		
		
		Car testobj=new Car();
		testobj.switchOnAC();
		
		Test testobj1=new Test();
		testobj1.airBags();
		testobj1.applyBrake();

}
}
