package week3.Day1.Inheritance;

public class BankInfo {
	
	protected BankInfo() {
		System.out.println("Bank Info constructor");
	}
	
	public void savings() {
		System.out.println("Savings Bank Info...");
	}
	
	 void fixed() {
		System.out.println("Fixed Bank acc..");
	}
	
	public void deposit() {
		System.out.println("Dposit Bank acc..");
	}

}
