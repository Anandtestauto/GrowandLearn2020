package week3.Day1.Inheritance;

public class AxisBank extends BankInfo{
	
	 int a;
	 int b;
	
	  private AxisBank(){
		  this(1,2); 
		System.out.println("Axis Bank constructor");  
	  }
	  
	
	  public AxisBank(int i, int j) {
		this.a=i;
		this.b=j;
	}


	public void AxisBankInfo(int a, int b){
		  this.a=a;
		  this.b=b; 
		  }
	 
	  public void deposit() {
	  System.out.println("Deposit bank acc for axis bank"); }
	 
	  public static void main(String[] args) {
		
	  AxisBank bank=new AxisBank();
	  System.out.println(bank.a);
	  System.out.println(bank.b);
	  bank.savings();
		
		
	}

}
