package week3.Day1;

public class BMW extends Car{
	
	protected void airBags() {
		System.out.println("airBag for all the passengers");

	}

}
