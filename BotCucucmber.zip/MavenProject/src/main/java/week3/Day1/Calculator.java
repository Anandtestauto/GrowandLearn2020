package week3.Day1;

public class Calculator {
	
	public void add(int a,int b) {
		System.out.println("Addition of a and b is "+(a+b));
		
	}
	
	public void add(int a,int b, int c) {
		System.out.println("Addition of a and b is "+(a+b+c));
		
	}
	
	public void multiply(int a,int b) {
		System.out.println("Multiplication of a and b is "+(a*b));
		
	}
	
	public void multiply(int a,double b) {
		System.out.println("Multiplication of a and b is "+(a*b));
		
	}
	
	public void subtract(int a,int b) {
		System.out.println("Multiplication of a and b is "+(a-b));
		
	}
	
	public void subtract(double a,double b) {
		System.out.println("Multiplication of a and b is "+(a-b));
		
	}
	
	public void divide(int a,int b) {
		System.out.println("Multiplication of a and b is "+(a/b));
		
	}
	
	public void divide(double a,int b) {
		System.out.println("Multiplication of a and b is "+(a/b));
		
	}
	
	public static void main(String[] args) {
		
		Calculator cal=new Calculator();
		cal.add(10, 5);
		cal.add(10, 15, 20);
		cal.divide(10.40, 2);
		cal.divide(20, 10);
		cal.multiply(2, 3);
		cal.subtract(20.02, 10.02);
		
		
		
	}

	
}
