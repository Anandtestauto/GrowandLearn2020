package week1Day1;

import java.util.Arrays;

public class MissingElementInArray {

	public static void main(String[] args) {
		/*
		 * int[] a= {1,2,3,4,5,7,8}; int missing;
		 * 
		 * for(int i=1;i<a.length;i++) {
		 * 
		 * missing=a[i-1]+1; // a[1-1]+1 missing=2
		 * 
		 * //System.out.println("Input in missing"+missing);
		 * 
		 * if(a[i]!=missing) {
		 * 
		 * System.out.println(missing); } }
		 */
		
		int num[]= {-1,0,1,2,3,4,5,7,8};
		
		int sum=0;
		for(int i=0;i<num.length;i++) {
			sum=sum+num[i];
		}
		
		
		int sum1=0;
		for(int j=-1;j<=8;j++) {
			sum1=sum1+j;
		}
		
		System.out.println(sum1-sum);

	}
}
