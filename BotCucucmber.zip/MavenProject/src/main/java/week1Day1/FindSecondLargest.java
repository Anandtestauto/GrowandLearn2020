package week1Day1;

import java.util.Arrays;

public class FindSecondLargest {

	public static void main(String[] args) {
		
		int[] numbers={9,5,3,5,56,58};

		Arrays.sort(numbers);
		
		System.out.println(numbers[numbers.length-2]);
		
	

		/*
		 * for(int i=numbers.length-1;i==numbers.length-1;i++){
		 * System.out.println(numbers[i]);
		 * 
		 * 
		 * }
		 */
	}
}
