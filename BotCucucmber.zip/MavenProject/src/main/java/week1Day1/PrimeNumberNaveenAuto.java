package week1Day1;

public class PrimeNumberNaveenAuto {
	
	 public static boolean isPrimeNumbers(int num) {
		//Number which is less than 1 are not prime numbers
		 if(num<=1) {
			 return false;
		 }
		 //Number 2 is the lowest prime number
		 for(int i=2;i<num;i++) {
			 if(num%i==0) {
				 return false;
			 }
			
		 }
		return true;

	}
	 
	 public  static void getPrimeNumbers(int num) {
		 for (int i=0;i<=num;i++) {
			 if(isPrimeNumbers(i)) {
				 System.out.print(i+" ");
			 }
		 }
		

	}

	public static void main(String[] args) {
		System.out.println(isPrimeNumbers(7));
		//getPrimeNumbers(10);
		
	}

}
