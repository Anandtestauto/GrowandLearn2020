package stringRelatedPrograms;

public class StringConcepts {
	

	 public static void main(String[] args) {
		 
		 //When the content is same for the difference objects, the value will be stored in the same location 
		 //And the reference variables will hold same memory address
		 //It will be string pool
		 //String Literal
			String str="India";
			String str1="India";
			
			
			System.out.println(str.toString());
			System.out.println(str.hashCode());
			System.out.println(str1.hashCode());
			System.out.println(str.equals(str1));
  
			
			//String Object
			//It will store heap memory
			String s=new String(str);
			String s1=new String(str1);	
			
			System.out.println(s.toString());
			System.out.println(s.hashCode());
			System.out.println(s1.hashCode());
			System.out.println(s.equals(s1));
			
			String s2=new String("Chennai");
			String s21=new String("Chennai");	
			
			System.out.println(s2.toString());
			System.out.println(s2.hashCode());
			System.out.println(s21.hashCode());
			System.out.println(s2.equals(s21));
			
		/*
		 * When the string values are re-intialized, the new values will be stored in
		 * the new memory location and the existing memory location will be derefered
		 * and garbage collected
		 */
			String testString="India";
			testString="Test";
			
			System.out.println(testString.toString());
			System.out.println(testString.hashCode());
			System.out.println(testString.equals(testString));
			
			//When the two objects have the same content, it will have same memory address
			
			String strobj=new String("TamilNadu");
			System.out.println(strobj.toString());
			System.out.println(strobj.hashCode());
			
			String strobj1=new String("TamilNadu");
			System.out.println(strobj1.toString());
			System.out.println(strobj1.hashCode());
			System.out.println(strobj.equals(strobj1));
			
			
			String s3="Sachin";  
			s3.concat(" Tendulkar");//concat() method appends the string at the end  
			System.out.println(s3);//will print Sachin because strings are immutable objects 
			
			String s4 = s3.concat(" Tendulkar");
			System.out.println(s4);
			
			System.out.println(s3.hashCode());
			System.out.println(s4.hashCode());
	}


}
