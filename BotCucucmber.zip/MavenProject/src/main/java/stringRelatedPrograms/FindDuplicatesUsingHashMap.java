package stringRelatedPrograms;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class FindDuplicatesUsingHashMap {

	public static void main(String[] args) {
		
		String text="Kaviyarasan";
		char ch='a';
		int count=0;
		
		System.out.println(text.length());
		
		
		  Map<Character, Integer> mp=new HashMap<Character, Integer>(); 
		  
		  for(int i=0;i<text.length();i++) {
			  if(text.charAt(i)==ch) {
				  count=count+1;
			  }
			  mp.put(ch, count);
		  }
		System.out.println(mp);
		
		for (Entry<Character, Integer> m : mp.entrySet()) {
			System.out.println(m.getKey()+" "+m.getValue());		
		}
	}

}
