package stringRelatedPrograms;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Anagram {

	public static void main(String[] args) {
		
		String s1="SILENT";
		String s2="LISTEN";
		
		
		  String s3 = s1.trim();
		  String s4 = s2.trim();
		  
		  char[] charArray1 = s3.toLowerCase().toCharArray(); 
		  char[] charArray2 = s4.toLowerCase().toCharArray();
		  
		  /*Arrays.sort(charArray1); 
		  Arrays.sort(charArray2);
		  
		  boolean anagram = Arrays.equals(charArray1, charArray2);
		  System.out.println(anagram);*/
		  
		 Map<Character,Integer> mp1=new HashMap<Character, Integer>();
		  
		 for(int i=0;i<charArray1.length;i++) {
			  mp1.put(charArray1[i], 1);	 
			 }
		 
		 Map<Character,Integer> mp2=new HashMap<Character, Integer>();
		 for(int j=0;j<charArray2.length;j++) {
			  mp2.put(charArray2[j], 1);
			 }
		 
		 for (Entry<Character, Integer> c : mp2.entrySet()) {
			 System.out.println(c.getKey()+" "+c.getValue());	
		}
		 
		
	
	
	
	
	}
	
	
		 
		
		

}
