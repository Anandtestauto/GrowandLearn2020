package stringRelatedPrograms;

public class ToSwapTheStringWithoutUsingTemp {

	public static void main(String[] args) {
		String a="Apple";
		String b="Kiwi";
		
		System.out.println("Before Swap"+a+" "+b);
		
		a=a+b;
		System.out.println(a);
		b=a.substring(0, a.length()-b.length());
		a=a.substring(0, a.length());
				
		System.out.println("After Swap"+a+" "+b);		

	}

}
